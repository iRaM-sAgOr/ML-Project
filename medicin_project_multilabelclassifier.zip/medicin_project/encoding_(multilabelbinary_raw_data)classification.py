import pandas as pd
from pandas import DataFrame
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.multiclass import OneVsRestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.linear_model import LogisticRegression, ElasticNet, Ridge, Lasso, LinearRegression


def split_y(y_arr):
    y_proc = []
    for i in y_arr:
        result = [x.strip() for x in i[0].split(',')]
        y_proc.append(result)
    return y_proc

#read csv data and take 1lac data from it and separate 3 columns of the data in x,x2,and y
df = pd.read_csv("medicine_prescription_records.csv", sep=',', index_col=0)
df_mod = df[:100000]
x = df_mod.iloc[:, 0:1].values
x_2 = df_mod.years_practicing
y = df_mod.iloc[:, 2:3].values

#create objects of binarizer and fit the first column
mlb = MultiLabelBinarizer()
mlb2 = MultiLabelBinarizer()
x_enc = mlb.fit_transform(x)
#send the y array in split function to convert every medicine name as a string value.and then fit it
y_arr = split_y(y)
y_enc = mlb2.fit_transform(y_arr)
print(type(x_enc), type(x_2), type(y_enc))
#convert the three encoded numpy array into three different dataframe and concat it in one to split the data in train test
data_drame1 = DataFrame(data=x_enc)
data_drame2 = DataFrame(data=x_2)
data_drame3 = DataFrame(data=y_enc)
merge_data = pd.concat([data_drame1, data_drame2, data_drame3], axis='columns')
print(merge_data, len(x_enc[0]))
train, test = train_test_split(merge_data, random_state=42, test_size=0.33, shuffle=True)
#split the data into x and y for both train and test
X_train = train.iloc[:, 0:238].values
X_test = test.iloc[:, 0:238].values
y_train = merge_data.iloc[:, 238:2433].values
y_test = test.iloc[:, 238:2433].values
print(X_train.shape, y_train.shape)
print(X_test.shape, y_test.shape)
result2 = []
#creating the model with various classifier
for base_clf in (MultinomialNB(), LogisticRegression(), LinearSVC(random_state=0),
                 LinearRegression(), Ridge(), ElasticNet(), Lasso(alpha=0.5)):
    clf = OneVsRestClassifier(base_clf).fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    ans = accuracy_score(y_test, y_pred)
    print("The ans is for :{} is =", ans)
    result2.append(ans)
print(result2)
