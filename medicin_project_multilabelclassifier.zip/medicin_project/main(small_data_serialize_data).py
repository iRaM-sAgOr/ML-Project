import pandas as pd
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.multiclass import OneVsRestClassifier
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression, ElasticNet, Ridge, Lasso, LinearRegression

df = pd.read_csv("sagor.csv", sep=',')
speciality = pd.get_dummies(df.specialty)
cms_prescription_counts = pd.get_dummies(df.cms_prescription_counts)
merge = pd.concat([df, speciality], axis='columns')
print("here is the type of speciality", type(speciality))
clean_merge = merge.drop(['specialty', "cms_prescription_counts"], axis='columns')
merge_second = pd.concat([clean_merge, cms_prescription_counts], axis='columns')
print(type(merge_second['General Practice'][0]))
train, test = train_test_split(merge_second, random_state=42, test_size=0.33, shuffle=True)
X_train = train.iloc[:, 0:2].values
print(type(train), train.shape, test.shape)
X_test = test.iloc[:, 0:2].values
y_train = train.iloc[:, 2:90].values
y_test = test.iloc[:, 2:90].values
# print(X_train, y_train)
for base_clf in (MultinomialNB(), LogisticRegression(), LinearSVC(random_state=0),
                 LinearRegression(), Ridge(), ElasticNet(), Lasso(alpha=0.5)):
    clf = OneVsRestClassifier(base_clf).fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    print("The ans is for :{} is =", accuracy_score(y_test, y_pred))
