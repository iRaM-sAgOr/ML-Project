*****************************************************************
                  Multilabelclassifier for integer data(encoded)
1. 10_test_data.csv has 10 of raw data for testing 
2. sagor.csv has serialize data that was processed from the raw data
3. medicine_prescription_records.csv is the main raw data
4. total_data.csv is the encoded data
5. main.py is the file that classify the sagor.csv data
6. full_data classify total_data.csv 
7. encoding.py file classify the raw data 
*******************************************************************
------------------ Necessary Link------------------
1. https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.MultiLabelBinarizer.html
2. https://stackoverflow.com/questions/24458645/label-encoding-across-multiple-columns-in-scikit-learn
3. https://scikit-learn.org/stable/modules/generated/sklearn.multiclass.OneVsRestClassifier.html
4. https://scikit-learn.org/stable/modules/multiclass.html
5. https://towardsdatascience.com/multi-label-text-classification-with-scikit-learn-30714b7819c5
*********************************************************************
------------------Description of Work---------------
1. coding description is mentioned in the code with comment as much as possible
2. Here are some more general knowledge
	a. MultinomialNB for neive method of classification
	b. LogisticRegression, ElasticNet, Ridge, Lasso, LinearRegression
this classifications are also used in the model
	c. In this project we have to use multi label classification
	d. Multi label classification means any row can have multiple class. That means any input has multiple binary output. For that we should use multilabel classification. To do so we need to encode the data with multi label one hot encoding and classify every medicine as one class.
	e. We use OneVsRest classifier for every classifier.
	f. to fit the data we need to encode the data with a form of 2d array or list.To know the thing we may see the 3 and 4 link as mentioned above.
	g. If we want to predict in real time than we need to save the object_name.classes_ of that perticular object.
*********************************************************************
------------------Reason of bad accuracy of that data--------------
1. We dont have sufficient data to train the model.
2. Dataset imbalanced distribution in the root cause.
3. During spliting data by train test it reduces the data for any class
4. If we use only few classes than we can have proper result.
**********************************************************************
-----------------Result of the model--------------------------------
1. we use 6 different classifier algorithm for the project
2. For less classes we have 70-80% accuracy for every classifier
3. We use 2500 classes of medicine here and 240 classes of features
**********************************************************************
---------------Challenges of the project----------------------------
1. Encoding the raw data as we required was the main and the toughest
   activity of the model
2. We have tried different way to preprocess the data with our required shape
3. Preporcessing a lot of data was difficult in that way
4. We need to take help from google colab for this full data as local pc is not suitable for that form of calculation.
5. Insufficient knowledge about the process at the first time lead us in different wrong way to make the model. As we have tried multi class classifier at the begining . And we re analyze the situation and reconsider the way of thinking. Then we finalize the way for the project as a multi label classification problem.
***********************************************************************
-----------------Related project of this study or knowledge-----------
1. we can classify any text data. It can be a news or movie gener according to the review .
2. For that project we can go through the text_classification_multilabel.ipynb file. And as well as  5 link in above.
3. For that we also have to know about tfidf and countvectorization ,bagofwords type algorithm as well.
4. The data is in data folder for this project

