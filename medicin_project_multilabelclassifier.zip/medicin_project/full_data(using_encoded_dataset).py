import numpy as np
import pandas as pd
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.multiclass import OneVsRestClassifier
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression, ElasticNet, Ridge, Lasso, LinearRegression


def get_train_and_test_data(ratio, df):
    """
    df["specialty"] = df["specialty"].apply(lambda x: list(map(int, x[1:-1].split(','))))
    df["years_practicing"] = [[i] for i in df["years_practicing"].values.tolist()]
    x = df[['specialty', 'years_practicing']].values.tolist()
    x = np.array(x)
    """

    df["specialty"] = df["specialty"].apply(lambda x: list(map(int, x[1:-1].split(','))))
    final = []
    for idx, i in enumerate(df["specialty"].values.tolist()):
        i.append(df["years_practicing"][idx])
        final.append(i)
        x = final

    y = df["cms_prescription_counts"].apply(lambda x: list(map(int, x[1:-1].split(','))))
    y = [i for i in y]  # original comment out if not needed
    result = []
    for i, j in enumerate(x):
        ar1 = x[i]
        ar2 = y[i]
        result.append(ar1 + ar2)
    x = np.array(x)
    y = np.array(y)
    result = np.array(result)
    return x, y, result


df = pd.read_csv("total_data.csv", index_col=0)
df = df[:10000]
x, y, result = get_train_and_test_data(0.8, df)
print(x.shape, y.shape, result.shape)
train, test = train_test_split(result, random_state=42, test_size=0.33, shuffle=True)
X_train = train[:, 0:160]
y_train = train[:, 160:1753]
X_test = test[:, 0:160]
y_test = test[:, 160:1753]
print(X_train.shape, y_train.shape)
print(X_test.shape, y_test.shape)
count = 0
acc = []
for base_clf in (MultinomialNB, LogisticRegression(), LinearSVC(random_state=0),
                 LinearRegression(), Ridge(), ElasticNet(), Lasso(alpha=0.5)):
    clf = OneVsRestClassifier(base_clf).fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    print("The ans is for :{} is =", accuracy_score(y_test, y_pred))
    print(count)
    count += 1
    acc.append(accuracy_score(y_test, y_pred))
print(acc)
